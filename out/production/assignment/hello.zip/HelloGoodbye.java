import java.util.Scanner;

public class HelloGoodbye {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String firstname = s.next();
        String lastname = s.next();
        System.out.println("Hello "+firstname+" "+lastname+".");
        System.out.println("Goodbye "+lastname+" "+firstname+".");


    }


}
