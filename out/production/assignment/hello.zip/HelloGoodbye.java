public class HelloGoodbye {
    public static void main(String[] args) {
        String firstname = args[0];
        String lastname = args[1];
        System.out.println("Hello "+firstname+" and "+lastname+".");
        System.out.println("Goodbye "+lastname+" and "+firstname+".");

    }


}
