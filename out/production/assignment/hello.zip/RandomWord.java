import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;


public class RandomWord {
    public static void main(String[] args) {
        int count=0;
        String champion="";
        while(true) {
            if(StdIn.isEmpty()) {
                StdOut.println(champion);
            }
            String a = StdIn.readString();
            count += 1;
            if (StdRandom.bernoulli(1.0/count)) {
                champion = a;
            }
        }
    }

}

